// registry stores a action , service,fields,views
// useService use to access odoo services
// this.orm use to connect with frontend to backend
import {Component, useState, onWillStart} from "@odoo/owl";
import {registry} from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class StudentDashboard extends Component {
    setup(){
        this.orm = useService("orm")

        this.state = useState({
            students: [],
            name:"",
            phone:"",
        });

        onWillStart(async ()=>{
            this.state.students = await this.orm.searchRead(
                "student.deatils",
                [],
                ["name","phone"]
            );
        });
        async createStudent(){
            if (!this.state.name || !this.state.phone){
                this.notification.add(
                    "please fill all details ",
                    {
                        type:"danger"
                    }
                );
                return;
            }
        }

    await this.orm.create(
        "student.deatils",
        [{
            name : this.state.name,
            phone: parseInt(this.state.phone),
        }]
    );

this.notification.add(
    "student create",
    {
        type: "success"
    }
);
        this.state.name = "";
        this.state.age = "";

        await this.loadStudents();

    }
}
StudentDashboard.template = "owl_practice.StudentDashboard";

registry.category("actions").add("owl_practice.student_dashboard", StudentDashboard);
